'''
Created on Jul 17, 2013

@author: scrosby
'''
from .Gus import Client

class QAForceClient(Client):
    pass